# DataCore Solutions Android App

Android WebView app containing the saved DataCore Solutions website.

## Build
Open the project in Android Studio, or use a GitHub Actions Android build workflow.
