# DataCore Solutions Android

Android WebView application for DataCore Solutions.

## App icon
The DataCore Solutions logo is configured as the launcher icon in all standard Android mipmap densities. `AndroidManifest.xml` references `@mipmap/ic_launcher` and `@mipmap/ic_launcher_round`.

## Build
Open this project in Android Studio, allow Gradle to sync, then use **Build > Build APK(s)**.
